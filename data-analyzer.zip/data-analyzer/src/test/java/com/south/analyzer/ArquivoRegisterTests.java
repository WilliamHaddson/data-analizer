package com.south.analyzer;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.south.analyzer.model.Cliente;
import com.south.analyzer.model.Item;
import com.south.analyzer.model.Venda;
import com.south.analyzer.model.Vendedor;
import com.south.analyzer.service.ArquivoRegisterService;

@SpringBootTest
class ArquivoRegisterTests {

	@Autowired
	private ArquivoRegisterService arquivoRegister;

	@Test
	public void criarArquivoTest() throws Exception {
		String relatorio = "Relatório de teste!";
		String filename = "teste.dat";
		
		
		arquivoRegister.criarArquivo(relatorio, filename);
		
		
		File arquivo = new File(System.getenv("HOMEPATH") + "/data/out/" + filename.replace(".dat", ".done.dat"));
		FileInputStream arquivoEntrada = new FileInputStream(arquivo);
		DataInputStream entrada = new DataInputStream(arquivoEntrada);
		String dadosVenda = new String(entrada.readAllBytes(), "UTF-8");
		
		assertThat(dadosVenda).isNotNull();
		assertThat(dadosVenda).isNotEmpty();
		assertThat(dadosVenda).isEqualTo(relatorio);
	}
	
	@Test
	public void atribuirVendasTest() {
		List<Vendedor> vendedores = new ArrayList<>();
		List<Cliente> clientes = new ArrayList<>();
		List<Venda> vendas = new ArrayList<>();
		List<Item> itens = new ArrayList<>();
		
		Vendedor vendedor = new Vendedor();
		vendedor.setNome("Joao");
		vendedor.setCpf("12345678910");
		vendedor.setSalario(Double.valueOf(30000));
		vendedores.add(vendedor);
		vendedor.setNome("Maria");
		vendedor.setCpf("12378954609");
		vendedor.setSalario(Double.valueOf(38000));
		vendedores.add(vendedor);
		
		Cliente cliente = new Cliente();
		cliente.setNome("Rafael");
		cliente.setCnpj("123456028439");
		cliente.setAreaTrabalho("Informatica");
		clientes.add(cliente);
		cliente.setNome("William");
		cliente.setCnpj("163821917392");
		cliente.setAreaTrabalho("Informatica");
		clientes.add(cliente);
		
		Venda venda = new Venda();
		Item item = new Item();
		venda.setNomeVendedor("Joao");
		venda.setVendaId(10L);
		item.setId(1L);
		item.setPreco(2.80);
		item.setQuantidade(3);
		itens.add(item);
		item.setId(2L);
		item.setPreco(Double.valueOf(20));
		item.setQuantidade(5);
		itens.add(item);
		venda.setItens(itens);
		vendas.add(venda);
		
		itens = new ArrayList<>();
		venda.setNomeVendedor("Joao");
		venda.setVendaId(5L);
		item.setId(1L);
		item.setPreco(2.80);
		item.setQuantidade(3);
		itens.add(item);
		item.setId(2L);
		item.setPreco(Double.valueOf(20));
		item.setQuantidade(5);
		itens.add(item);
		venda.setItens(itens);
		vendas.add(venda);
		
		itens = new ArrayList<>();
		venda.setNomeVendedor("Maria");
		venda.setVendaId(8L);
		item.setId(1L);
		item.setPreco(2.80);
		item.setQuantidade(3);
		itens.add(item);
		item.setId(2L);
		item.setPreco(Double.valueOf(20));
		item.setQuantidade(5);
		itens.add(item);
		venda.setItens(itens);
		vendas.add(venda);
		
		vendedores = arquivoRegister.atribuirVendas(vendedores, vendas);
		
		vendedores.forEach(vendedorTeste -> {
			vendedorTeste.getVendas().forEach(vendaTeste -> {
				assertThat(vendaTeste).isNotNull();
			});
		});
		
	}
	
	@Test
	public void montarRelatorioTest() {
		List<Vendedor> vendedores = new ArrayList<>();
		List<Cliente> clientes = new ArrayList<>();
		List<Venda> vendas = new ArrayList<>();
		List<Item> itens = new ArrayList<>();
		
		Vendedor vendedor = new Vendedor();
		vendedor.setNome("Joao");
		vendedor.setCpf("12345678910");
		vendedor.setSalario(Double.valueOf(30000));
		vendedores.add(vendedor);
		vendedor.setNome("Maria");
		vendedor.setCpf("12378954609");
		vendedor.setSalario(Double.valueOf(38000));
		vendedores.add(vendedor);
		
		Cliente cliente = new Cliente();
		cliente.setNome("Rafael");
		cliente.setCnpj("123456028439");
		cliente.setAreaTrabalho("Informatica");
		clientes.add(cliente);
		cliente.setNome("William");
		cliente.setCnpj("163821917392");
		cliente.setAreaTrabalho("Informatica");
		clientes.add(cliente);
		
		Venda venda = new Venda();
		Item item = new Item();
		venda.setNomeVendedor("Joao");
		venda.setVendaId(10L);
		item.setId(1L);
		item.setPreco(2.80);
		item.setQuantidade(3);
		itens.add(item);
		item.setId(2L);
		item.setPreco(Double.valueOf(20));
		item.setQuantidade(5);
		itens.add(item);
		venda.setItens(itens);
		vendas.add(venda);
		
		itens = new ArrayList<>();
		venda.setNomeVendedor("Joao");
		venda.setVendaId(5L);
		item.setId(1L);
		item.setPreco(2.80);
		item.setQuantidade(3);
		itens.add(item);
		item.setId(2L);
		item.setPreco(Double.valueOf(20));
		item.setQuantidade(5);
		itens.add(item);
		venda.setItens(itens);
		vendas.add(venda);
		
		itens = new ArrayList<>();
		venda.setNomeVendedor("Maria");
		venda.setVendaId(8L);
		item.setId(1L);
		item.setPreco(2.80);
		item.setQuantidade(3);
		itens.add(item);
		item.setId(2L);
		item.setPreco(Double.valueOf(20));
		item.setQuantidade(5);
		itens.add(item);
		venda.setItens(itens);
		vendas.add(venda);
		
		vendedores = arquivoRegister.atribuirVendas(vendedores, vendas);
		
		String relatorio = arquivoRegister.montarRelatorio(vendedores, clientes, vendas);
		
		assertThat(relatorio).isNotNull();
		assertThat(relatorio).isNotEmpty();
		
	}

}
