package com.south.analyzer.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Item {
	
	private Long id;
	private Integer quantidade;
	private Double preco;

}
